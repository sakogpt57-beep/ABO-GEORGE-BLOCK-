package com.abogeorge.block

import android.net.VpnService
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * Small user-space IPv4 relay. Packets read from the tunnel are re-sent through protected sockets, which lets us
 *  - answer DNS queries for ad/tracker domains with NXDOMAIN (ad blocking),
 *  - slow the traffic down (speed saver),
 *  - drop flows that belong to blocked apps (firewall).
 * IPv6 and ICMP are dropped (apps fall back to IPv4).
 */
class Relay(
    private val vpn: VpnService,
    private val out: FileOutputStream,
    /** proto, client ip, client port, server ip, server port -> uid to allow, or BLOCK. */
    private val decide: (Int, ByteArray, Int, ByteArray, Int) -> Int,
    private val blockedUid: (Int) -> Boolean,
    private val onAd: (String) -> Unit
) {
    companion object {
        const val BLOCK = -1
        private const val FIN = 1
        private const val SYN = 2
        private const val RST = 4
        private const val PSH = 8
        private const val ACK = 16
        private const val M = 0xFFFFFFFFL
    }

    @Volatile var adBlock = false
    private data class K(val a: Long, val b: Long)

    private val pool = Executors.newCachedThreadPool()
    private val tcps = ConcurrentHashMap<K, Tcp>()
    private val udps = ConcurrentHashMap<K, Udp>()
    private val timer = Executors.newSingleThreadScheduledExecutor()

    init {
        timer.scheduleWithFixedDelay({ try { sweep() } catch (_: Throwable) {} }, 500, 500, TimeUnit.MILLISECONDS)
    }

    private fun write(p: ByteArray) { synchronized(out) { try { out.write(p) } catch (_: Exception) {} } }
    private fun gt(a: Long, b: Long): Boolean { val d = (a - b) and M; return d != 0L && d < 0x80000000L }

    fun shutdown() {
        timer.shutdownNow()
        for (s in tcps.values) s.close()
        for (u in udps.values) u.close()
        pool.shutdownNow()
    }

    /** Called after the rules changed: cut flows of apps that just became blocked. */
    fun recheck() {
        for (s in tcps.values) if (blockedUid(s.uid)) s.reset()
        for (u in udps.values) if (blockedUid(u.uid)) u.close()
    }

    private fun sweep() {
        val now = System.currentTimeMillis()
        for (s in tcps.values) s.tick(now)
        for (u in udps.values) if (now - u.last > u.ttl) u.close()
    }

    fun handle(b: ByteArray, n: Int) {
        if (n < 20 || ((b[0].toInt() shr 4) and 15) != 4) return
        val ihl = (b[0].toInt() and 15) * 4
        val frag = Pkt.u16(b, 6)
        if ((frag and 0x1fff) != 0 || (frag and 0x2000) != 0 || n < ihl + 8) return
        when (b[9].toInt() and 255) {
            6 -> tcp(b, n, ihl)
            17 -> udp(b, n, ihl)
        }
    }

    // ---------------------------------------------------------------- UDP

    private fun udp(b: ByteArray, n: Int, ihl: Int) {
        val end = minOf(n, Pkt.u16(b, 2))
        if (end < ihl + 8) return
        val cp = Pkt.u16(b, ihl)
        val sp = Pkt.u16(b, ihl + 2)
        val pOff = ihl + 8
        val plen = end - pOff
        val cip = b.copyOfRange(12, 16)
        val sip = b.copyOfRange(16, 20)
        val k = K((Pkt.u32(cip, 0) shl 16) or cp.toLong(), (Pkt.u32(sip, 0) shl 16) or sp.toLong())
        var u = udps[k]
        if (u == null) {
            val uid = decide(17, cip, cp, sip, sp)
            if (uid == BLOCK) return
            u = Udp(k, uid, cip, sip, cp, sp)
            udps[k] = u
        }
        if (sp == 853) return
        if (sp == 53) {
            val q = Dns.parse(b, pOff, plen)
            if (q != null) {
                if (adBlock && Blocklist.matches(q.name)) {
                    onAd(q.name)
                    val r = Dns.reply(b, pOff, q, 3)
                    write(Pkt.udp(sip, cip, sp, cp, r, r.size))
                    return
                }
                if (q.type == 28) { // AAAA: answer "no data" so apps use IPv4 (IPv6 is not relayed)
                    val r = Dns.reply(b, pOff, q, 0)
                    write(Pkt.udp(sip, cip, sp, cp, r, r.size))
                    return
                }
            }
        }
        u.send(b.copyOfRange(pOff, pOff + plen))
    }

    private inner class Udp(val k: K, val uid: Int, val cip: ByteArray, val sip: ByteArray, val cp: Int, val sp: Int) {
        private var so: DatagramSocket? = null
        @Volatile var last = System.currentTimeMillis()
        @Volatile private var closed = false
        val ttl = if (sp == 53) 8_000L else 90_000L

        @Synchronized fun send(d: ByteArray) {
            if (closed) return
            try {
                var s = so
                if (s == null) {
                    s = DatagramSocket()
                    vpn.protect(s)
                    so = s
                    val sock = s
                    pool.execute { recv(sock) }
                }
                s.send(DatagramPacket(d, d.size, InetAddress.getByAddress(sip), sp))
                last = System.currentTimeMillis()
            } catch (_: Exception) { close() }
        }

        private fun recv(s: DatagramSocket) {
            val buf = ByteArray(2048)
            try {
                while (!closed) {
                    val p = DatagramPacket(buf, buf.size)
                    s.receive(p)
                    last = System.currentTimeMillis()
                    if (p.length > 1472) continue
                    Throttle.take(p.length)
                    write(Pkt.udp(sip, cip, sp, cp, buf, p.length))
                }
            } catch (_: Exception) {}
            close()
        }

        fun close() {
            closed = true
            try { so?.close() } catch (_: Exception) {}
            udps.remove(k)
        }
    }

    // ---------------------------------------------------------------- TCP

    private fun tcp(b: ByteArray, n: Int, ihl: Int) {
        val end = minOf(n, Pkt.u16(b, 2))
        if (end < ihl + 20) return
        val cp = Pkt.u16(b, ihl)
        val sp = Pkt.u16(b, ihl + 2)
        val seq = Pkt.u32(b, ihl + 4)
        val ack = Pkt.u32(b, ihl + 8)
        val doff = ((b[ihl + 12].toInt() shr 4) and 15) * 4
        val fl = b[ihl + 13].toInt() and 63
        val win = Pkt.u16(b, ihl + 14)
        val pOff = ihl + doff
        if (doff < 20 || pOff > end) return
        val plen = end - pOff
        val cip = b.copyOfRange(12, 16)
        val sip = b.copyOfRange(16, 20)
        val k = K((Pkt.u32(cip, 0) shl 16) or cp.toLong(), (Pkt.u32(sip, 0) shl 16) or sp.toLong())
        val s = tcps[k]
        if ((fl and RST) != 0) { s?.close(); return }
        if (s == null) {
            val syn = (fl and SYN) != 0
            if (!syn) { if (plen > 0 || (fl and FIN) != 0) rstFor(cip, sip, cp, sp, seq, ack, fl, plen); return }
            if (sp == 853) { rstFor(cip, sip, cp, sp, seq, ack, fl, plen); return } // DoT: force plain DNS
            val uid = decide(6, cip, cp, sip, sp)
            if (uid == BLOCK) return
            val t = Tcp(k, uid, cip, sip, cp, sp, seq)
            tcps[k] = t
            pool.execute { t.connect() }
            return
        }
        s.onPkt(fl, seq, ack, win, b, pOff, plen)
    }

    private fun rstFor(cip: ByteArray, sip: ByteArray, cp: Int, sp: Int, seq: Long, ack: Long, fl: Int, plen: Int) {
        if ((fl and ACK) != 0) write(Pkt.tcp(sip, cip, sp, cp, ack, 0, RST, 0, null, 0, false))
        else {
            val ex = plen + (if ((fl and (SYN or FIN)) != 0) 1 else 0)
            write(Pkt.tcp(sip, cip, sp, cp, 0, (seq + ex) and M, RST or ACK, 0, null, 0, false))
        }
    }

    private inner class Tcp(val k: K, val uid: Int, val cip: ByteArray, val sip: ByteArray, val cp: Int, val sp: Int, isn: Long) {
        @Volatile var st = 0 // 0 connecting, 1 open, 2 closed
        @Volatile var rcv = (isn + 1) and M
        private var snd = java.util.Random().nextInt().toLong() and M
        private var una = 0L
        private var synSeq = 0L
        private var peerWin = 65535
        private var lastProg = 0L
        private var finSent = false
        private var finGot = false
        @Volatile var last = System.currentTimeMillis()
        private var sock: Socket? = null
        private val wq = LinkedBlockingQueue<ByteArray>()
        private val unacked = ArrayDeque<Pair<Long, ByteArray>>()
        private val lk = ReentrantLock()
        private val cond = lk.newCondition()

        private fun tx(fl: Int, seq: Long, d: ByteArray?, n: Int, mss: Boolean = false) {
            write(Pkt.tcp(sip, cip, sp, cp, seq, rcv, fl, 65535, d, n, mss))
        }

        fun connect() {
            val so = Socket()
            try {
                vpn.protect(so)
                so.tcpNoDelay = true
                so.connect(InetSocketAddress(InetAddress.getByAddress(sip), sp), 8000)
            } catch (_: Exception) {
                try { so.close() } catch (_: Exception) {}
                if (st != 2) tx(RST or ACK, 0, null, 0)
                close()
                return
            }
            lk.withLock {
                if (st == 2) { try { so.close() } catch (_: Exception) {}; return }
                sock = so
                synSeq = snd
                tx(SYN or ACK, snd, null, 0, true)
                snd = (snd + 1) and M
                una = snd
                lastProg = System.currentTimeMillis()
                st = 1
            }
            pool.execute { writer() }
            pool.execute { reader() }
        }

        fun onPkt(fl: Int, seq: Long, ack: Long, win: Int, b: ByteArray, off: Int, len: Int) {
            last = System.currentTimeMillis()
            if (st != 1) return
            if ((fl and SYN) != 0) {
                lk.withLock { if (snd == ((synSeq + 1) and M)) tx(SYN or ACK, synSeq, null, 0, true) }
                return
            }
            if ((fl and ACK) != 0) lk.withLock {
                if (gt(ack, una) && !gt(ack, snd)) {
                    una = ack
                    lastProg = last
                    while (unacked.isNotEmpty()) {
                        val f = unacked.first()
                        if (gt((f.first + f.second.size) and M, una)) break
                        unacked.removeFirst()
                    }
                }
                peerWin = win
                cond.signalAll()
            }
            var needAck = false
            if (len > 0) {
                var dOff = off
                var dLen = len
                var ok = false
                val behind = (rcv - seq) and M
                if (behind == 0L) ok = true
                else if (behind < 0x80000000L && behind < dLen) { dOff += behind.toInt(); dLen -= behind.toInt(); ok = true }
                needAck = true
                if (ok) {
                    wq.offer(b.copyOfRange(dOff, dOff + dLen))
                    rcv = (rcv + dLen) and M
                }
            }
            if ((fl and FIN) != 0 && !finGot && ((seq + len) and M) == rcv) {
                finGot = true
                rcv = (rcv + 1) and M
                wq.offer(ByteArray(0))
                needAck = true
            }
            if (needAck) lk.withLock { tx(ACK, snd, null, 0) }
            val done = lk.withLock { finSent && finGot && una == snd }
            if (done) close()
        }

        fun writer() {
            try {
                val o = sock!!.getOutputStream()
                while (true) {
                    val d = wq.take()
                    if (d.isEmpty()) { try { sock?.shutdownOutput() } catch (_: Exception) {}; return }
                    o.write(d)
                }
            } catch (_: Exception) { reset() }
        }

        fun reader() {
            val buf = ByteArray(1360)
            try {
                val i = sock!!.getInputStream()
                while (st == 1) {
                    val n = i.read(buf)
                    if (n < 0) break
                    last = System.currentTimeMillis()
                    Throttle.take(n)
                    lk.withLock {
                        while (st == 1) {
                            val fly = ((snd - una) and M)
                            if (fly == 0L || fly + n <= peerWin) break
                            cond.await(300, TimeUnit.MILLISECONDS)
                        }
                        if (st != 1) return
                        val seg = buf.copyOf(n)
                        if (una == snd) lastProg = System.currentTimeMillis()
                        unacked.addLast(Pair(snd, seg))
                        tx(PSH or ACK, snd, seg, n)
                        snd = (snd + n) and M
                    }
                }
                lk.withLock {
                    if (st == 1) {
                        if (una == snd) lastProg = System.currentTimeMillis()
                        tx(FIN or ACK, snd, null, 0)
                        finSent = true
                        snd = (snd + 1) and M
                    }
                }
            } catch (_: Exception) { reset() }
        }

        fun tick(now: Long) {
            if (st == 2) { tcps.remove(k); return }
            if (now - last > (if (st == 0) 20_000L else 1_800_000L)) { close(); return }
            lk.withLock {
                if (st == 1 && una != snd && now - lastProg > 1000) {
                    if (now - lastProg > 60_000) { reset(); return }
                    val f = unacked.firstOrNull()
                    if (f != null) tx(PSH or ACK, f.first, f.second, f.second.size)
                    else if (finSent) tx(FIN or ACK, (snd - 1) and M, null, 0)
                }
            }
        }

        fun reset() {
            if (st == 2) return
            try { lk.withLock { tx(RST or ACK, snd, null, 0) } } catch (_: Exception) {}
            close()
        }

        fun close() {
            if (st == 2) return
            st = 2
            try { sock?.close() } catch (_: Exception) {}
            wq.offer(ByteArray(0))
            tcps.remove(k)
            lk.withLock { cond.signalAll() }
        }
    }
}
