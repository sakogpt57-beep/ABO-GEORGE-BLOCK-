package com.abogeorge.block

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService

/** Restarts the firewall after reboot / app update when it was on and auto-start is enabled. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        try {
            val p = c.getSharedPreferences("abo", Context.MODE_PRIVATE)
            if (p.getBoolean("on", false) && p.getBoolean("boot", true) && VpnService.prepare(c) == null)
                c.startForegroundService(Intent(c, BlockVpnService::class.java))
        } catch (_: Exception) {}
    }
}
