package com.abogeorge.block

import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import android.os.Process
import org.json.JSONObject
import java.io.FileInputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.ConcurrentHashMap

/**
 * Local VPN firewall. Apps that must be blocked on the current network (wifi / mobile)
 * are the only ones routed into the tunnel; packets are read and dropped, never forwarded.
 * Allowed apps bypass the VPN entirely, so they keep normal speed and connectivity.
 */
class BlockVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    private var wifi = true
    private var registered = false
    private var rxReg = false
    private var lastSig: String? = null
    @Volatile private var fg: String? = null
    @Volatile private var poller: Thread? = null
    private val notified: MutableSet<String> = ConcurrentHashMap.newKeySet<String>()

    /** screen on/off + app installed/removed -> recompute who must be blocked */
    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { apply() }
    }

    private val cb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(n: Network) = changed()
        override fun onLost(n: Network) = changed()
        override fun onCapabilitiesChanged(n: Network, c: NetworkCapabilities) = changed()
    }

    private fun hasUsage(): Boolean {
        val ao = getSystemService(AppOpsManager::class.java)
        @Suppress("DEPRECATION")
        return ao.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    /** Watches which app is on screen (needs usage-access) so "foreground only" mode can follow it. */
    private fun startPoller() {
        if (poller != null) return
        poller = Thread {
            val um = getSystemService(UsageStatsManager::class.java)
            var lastQ = 0L
            var primed = false
            while (!Thread.currentThread().isInterrupted) {
                val want = getSharedPreferences("abo", MODE_PRIVATE).getBoolean("bg", false) && hasUsage()
                try { Thread.sleep(if (want) 1000L else 3000L) } catch (_: InterruptedException) { break }
                if (!want) { primed = false; continue }
                val now = System.currentTimeMillis()
                // first pass looks back one hour so the app already on screen is detected
                if (!primed) lastQ = now - 3_600_000L
                var cur = fg
                try {
                    val ev = um.queryEvents(lastQ, now)
                    val e = UsageEvents.Event()
                    while (ev.hasNextEvent()) {
                        ev.getNextEvent(e)
                        if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED && e.packageName != packageName) cur = e.packageName
                    }
                } catch (_: Exception) {}
                primed = true
                lastQ = now - 1000
                if (cur != fg) { fg = cur; apply() }
            }
        }.also { it.start() }
    }

    private fun changed() {
        val cm = getSystemService(ConnectivityManager::class.java)
        if (Net.isWifi(cm) != wifi) apply()
    }

    private fun foreground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("blk", "ABO GEORGE BLOCK", NotificationManager.IMPORTANCE_MIN))
        nm.createNotificationChannel(NotificationChannel("pend", "طلبات الاتصال", NotificationManager.IMPORTANCE_DEFAULT))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "blk").setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("ABO GEORGE BLOCK").setContentText("الجدار يعمل")
            .setContentIntent(pi).setOngoing(true).build()
        startForeground(1, n)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        foreground()
        if (!registered) {
            try {
                val cm = getSystemService(ConnectivityManager::class.java)
                cm.registerNetworkCallback(
                    NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                        .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN).build(), cb)
                registered = true
            } catch (_: Exception) {}
        }
        if (!rxReg) {
            registerReceiver(rx, IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_SCREEN_OFF)
            })
            registerReceiver(rx, IntentFilter().apply {
                addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
                addDataScheme("package")
            })
            rxReg = true
        }
        startPoller()
        apply()
        return START_STICKY
    }

    @Synchronized private fun apply() {
        try { applyInner() } catch (t: Throwable) {
            Hub.err = "تعذّر تشغيل الجدار: " + t.javaClass.simpleName + " " + (t.message ?: "")
            Hub.running = false
        }
    }

    private fun applyInner() {
        val p = getSharedPreferences("abo", MODE_PRIVATE)
        if (!p.getBoolean("on", false)) { stopSelf(); return }
        val cm = getSystemService(ConnectivityManager::class.java)
        wifi = Net.isWifi(cm)
        val rules = JSONObject(p.getString("rules", "{}") ?: "{}")
        val key = if (wifi) "w" else "m"
        val capped = p.getBoolean("capped", false) && !wifi
        val bg = p.getBoolean("bg", false) && hasUsage()   // without usage access this mode stays off
        val soff = p.getBoolean("soff", false)
        val screenOn = getSystemService(PowerManager::class.java).isInteractive
        val curFg = fg

        val blocked = ArrayList<String>()
        for (a in packageManager.getInstalledApplications(0)) {
            val pk = a.packageName
            if (pk == packageName) continue
            val r = rules.optJSONObject(pk)
            var allow = r?.optBoolean(key, false) == true
            if (allow && capped) allow = false
            if (allow && r?.optBoolean("k", false) != true) {
                if (soff && !screenOn) allow = false
                else if (bg && pk != curFg) allow = false
            }
            if (!allow) blocked.add(pk)
        }
        blocked.sort()
        val sig = blocked.joinToString(",")
        // nothing changed: keep the current tunnel, avoid a needless reconnect
        if (tun != null && sig == lastSig) { Hub.running = true; return }

        val b = Builder().setSession("ABO GEORGE BLOCK")
            .addAddress("10.8.0.1", 32).addAddress("fd00::1", 128)
            .addRoute("0.0.0.0", 0).addRoute("::", 0)
            .setBlocking(true)
        var n = 0
        for (pk in blocked) {
            try { b.addAllowedApplication(pk); n++ } catch (_: Exception) {}
        }
        if (n == 0) b.addAllowedApplication(packageName) // nothing to block: route nobody

        val nt = b.establish()
        if (nt == null) {
            Hub.running = false
            Hub.err = "تعذّر إنشاء النفق: صلاحية VPN غير ممنوحة، اضغط تشغيل مرة ثانية"
            return
        }
        val old = tun
        tun = nt
        lastSig = sig
        old?.close()
        Thread { watch(nt) }.start()
        Hub.running = true
        Hub.err = ""
    }

    /** Reads packets from the tunnel (they are dropped, never forwarded) and reports who tried to connect. */
    private fun watch(fd: ParcelFileDescriptor) {
        val s = FileInputStream(fd.fileDescriptor)
        val buf = ByteArray(32767)
        val cm = getSystemService(ConnectivityManager::class.java)
        val seen = HashMap<Int, Long>()   // (proto, source port) -> last lookup, avoids a binder call per packet
        val last = HashMap<Int, Long>()   // uid -> last report
        while (true) {
            val n = try { s.read(buf) } catch (_: Exception) { -1 }
            if (n < 0) break
            if (n == 0) continue
            try {
                val v = (buf[0].toInt() shr 4) and 15
                val hdr: Int
                val proto: Int
                val src: ByteArray
                val dst: ByteArray
                if (v == 4 && n >= 24) {
                    hdr = (buf[0].toInt() and 15) * 4; proto = buf[9].toInt() and 255
                    src = buf.copyOfRange(12, 16); dst = buf.copyOfRange(16, 20)
                } else if (v == 6 && n >= 44) {
                    hdr = 40; proto = buf[6].toInt() and 255
                    src = buf.copyOfRange(8, 24); dst = buf.copyOfRange(24, 40)
                } else continue
                if ((proto != 6 && proto != 17) || n < hdr + 4) continue
                val sp = ((buf[hdr].toInt() and 255) shl 8) or (buf[hdr + 1].toInt() and 255)
                val dp = ((buf[hdr + 2].toInt() and 255) shl 8) or (buf[hdr + 3].toInt() and 255)
                val now = System.currentTimeMillis()
                val k = (proto shl 16) or sp
                if (now - (seen[k] ?: 0L) < 4000) continue
                seen[k] = now
                if (seen.size > 4000) seen.clear()
                val da = InetAddress.getByAddress(dst)
                val uid = cm.getConnectionOwnerUid(proto, InetSocketAddress(InetAddress.getByAddress(src), sp), InetSocketAddress(da, dp))
                if (uid < 0) continue
                if (now - (last[uid] ?: 0L) < 4000) continue
                last[uid] = now
                val pkg = packageManager.getPackagesForUid(uid)?.firstOrNull() ?: continue
                Hub.add(pkg, da.hostAddress ?: "", dp, if (wifi) "wifi" else "mobile")
                notifyPending(pkg)
            } catch (_: Exception) {}
        }
    }

    private fun notifyPending(pkg: String) {
        val p = getSharedPreferences("abo", MODE_PRIVATE)
        if (JSONObject(p.getString("rules", "{}") ?: "{}").has(pkg) || !notified.add(pkg)) return
        val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg }
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "pend").setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(label).setContentText("يحاول الاتصال بالإنترنت: اسمح له أو ارفضه")
            .setContentIntent(pi).setAutoCancel(true).build()
        getSystemService(NotificationManager::class.java).notify(pkg.hashCode(), n)
    }

    override fun onRevoke() {
        getSharedPreferences("abo", MODE_PRIVATE).edit().putBoolean("on", false).apply()
        Hub.running = false
        super.onRevoke()
    }

    override fun onDestroy() {
        if (registered) try { getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(cb) } catch (_: Exception) {}
        registered = false
        poller?.interrupt(); poller = null
        if (rxReg) try { unregisterReceiver(rx) } catch (_: Exception) {}
        rxReg = false
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        lastSig = null
        Hub.running = false
        super.onDestroy()
    }
}
