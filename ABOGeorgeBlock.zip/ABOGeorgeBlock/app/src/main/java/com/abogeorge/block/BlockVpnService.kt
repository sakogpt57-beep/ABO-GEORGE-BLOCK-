package com.abogeorge.block

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.os.PowerManager
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.ParcelFileDescriptor
import org.json.JSONObject
import java.io.FileInputStream
import java.net.InetAddress
import java.net.InetSocketAddress

/**
 * Local VPN firewall. Apps that must be blocked on the current network (wifi / mobile)
 * are the only ones routed into the tunnel; packets are read and dropped, never forwarded.
 * Allowed apps bypass the VPN entirely, so they keep normal speed and connectivity.
 */
class BlockVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    private var wifi = true
    private var registered = false
    private var screenReg = false
    @Volatile private var fg: String? = null
    private var poller: Thread? = null
    private val screenRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { apply() }
    }

    /** Watches which app is on screen (needs usage-access) so "foreground only" mode can follow it. */
    private fun startPoller() {
        if (poller != null) return
        poller = Thread {
            val um = getSystemService(UsageStatsManager::class.java)
            var lastQ = System.currentTimeMillis() - 5000
            while (!Thread.currentThread().isInterrupted) {
                try { Thread.sleep(1000) } catch (_: InterruptedException) { break }
                if (!getSharedPreferences("abo", MODE_PRIVATE).getBoolean("bg", false)) continue
                val now = System.currentTimeMillis()
                var cur = fg
                try {
                    val ev = um.queryEvents(lastQ, now)
                    val e = UsageEvents.Event()
                    while (ev.hasNextEvent()) {
                        ev.getNextEvent(e)
                        if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) cur = e.packageName
                    }
                } catch (_: Exception) {}
                lastQ = now - 1000
                if (cur != fg) { fg = cur; apply() }
            }
        }.also { it.start() }
    }
    private val cb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(n: Network) = changed()
        override fun onLost(n: Network) = changed()
        override fun onCapabilitiesChanged(n: Network, c: NetworkCapabilities) = changed()
    }

    private fun isWifi(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java)
        @Suppress("DEPRECATION")
        return cm.allNetworks.any {
            val c = cm.getNetworkCapabilities(it)
            c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN) &&
                (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))
        }
    }

    private fun changed() { if (isWifi() != wifi) apply() }

    private fun foreground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("blk", "ABO GEORGE BLOCK", NotificationManager.IMPORTANCE_MIN))
        nm.createNotificationChannel(NotificationChannel("pend", "طلبات الاتصال", NotificationManager.IMPORTANCE_DEFAULT))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "blk").setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("ABO GEORGE BLOCK").setContentText("الجدار يعمل")
            .setContentIntent(pi).setOngoing(true).build()
        startForeground(1, n)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        foreground()
        if (!registered) {
            val cm = getSystemService(ConnectivityManager::class.java)
            cm.registerNetworkCallback(
                NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN).build(), cb)
            registered = true
        }
        if (!screenReg) {
            registerReceiver(screenRx, IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_SCREEN_OFF)
            })
            screenReg = true
        }
        startPoller()
        apply()
        return START_STICKY
    }

    @Synchronized private fun apply() {
        val p = getSharedPreferences("abo", MODE_PRIVATE)
        if (!p.getBoolean("on", false)) { stopSelf(); return }
        wifi = isWifi()
        val rules = JSONObject(p.getString("rules", "{}")!!)
        val key = if (wifi) "w" else "m"
        val bg = p.getBoolean("bg", false)
        val soff = p.getBoolean("soff", false)
        val screenOn = getSystemService(PowerManager::class.java).isInteractive
        val b = Builder().setSession("ABO GEORGE BLOCK")
            .addAddress("10.8.0.1", 32).addAddress("fd00::1", 128)
            .addRoute("0.0.0.0", 0).addRoute("::", 0)
            .setBlocking(true)
        var n = 0
        for (a in packageManager.getInstalledApplications(0)) {
            if (a.packageName == packageName) continue
            val r = rules.optJSONObject(a.packageName)
            var allow = r?.optBoolean(key, false) == true
            if (allow && r?.optBoolean("k", false) != true) {
                if (soff && !screenOn) allow = false
                else if (bg && a.packageName != fg) allow = false
            }
            if (allow) continue
            try { b.addAllowedApplication(a.packageName); n++ } catch (_: Exception) {}
        }
        if (n == 0) b.addAllowedApplication(packageName) // nothing to block: route nobody
        val old = tun
        tun = b.establish()
        old?.close()
        tun?.let { fd -> Thread { watch(fd) }.start() }
        Hub.running = tun != null
    }

    private val notified = HashSet<String>()

    /** Reads packets from the tunnel (they are dropped, never forwarded) and reports who tried to connect. */
    private fun watch(fd: ParcelFileDescriptor) {
        val s = FileInputStream(fd.fileDescriptor)
        val buf = ByteArray(32767)
        val cm = getSystemService(ConnectivityManager::class.java)
        val last = HashMap<Int, Long>()
        while (true) {
            val n = try { s.read(buf) } catch (_: Exception) { -1 }
            if (n < 0) break
            try {
                val v = (buf[0].toInt() shr 4) and 15
                var hdr = 0; var proto = -1
                var src = ByteArray(0); var dst = ByteArray(0)
                if (v == 4 && n >= 24) {
                    hdr = (buf[0].toInt() and 15) * 4; proto = buf[9].toInt() and 255
                    src = buf.copyOfRange(12, 16); dst = buf.copyOfRange(16, 20)
                } else if (v == 6 && n >= 44) {
                    hdr = 40; proto = buf[6].toInt() and 255
                    src = buf.copyOfRange(8, 24); dst = buf.copyOfRange(24, 40)
                } else continue
                if ((proto != 6 && proto != 17) || n < hdr + 4) continue
                val sp = ((buf[hdr].toInt() and 255) shl 8) or (buf[hdr + 1].toInt() and 255)
                val dp = ((buf[hdr + 2].toInt() and 255) shl 8) or (buf[hdr + 3].toInt() and 255)
                val da = InetAddress.getByAddress(dst)
                val uid = cm.getConnectionOwnerUid(proto, InetSocketAddress(InetAddress.getByAddress(src), sp), InetSocketAddress(da, dp))
                if (uid < 0) continue
                val now = System.currentTimeMillis()
                if (now - (last[uid] ?: 0L) < 4000) continue
                last[uid] = now
                val pkg = packageManager.getPackagesForUid(uid)?.firstOrNull() ?: continue
                Hub.add(pkg, da.hostAddress ?: "", dp, if (wifi) "wifi" else "mobile")
                notifyPending(pkg)
            } catch (_: Exception) {}
        }
    }

    private fun notifyPending(pkg: String) {
        val p = getSharedPreferences("abo", MODE_PRIVATE)
        if (JSONObject(p.getString("rules", "{}")!!).has(pkg) || !notified.add(pkg)) return
        val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg }
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "pend").setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle(label).setContentText("يحاول الاتصال بالإنترنت: اسمح له أو ارفضه")
            .setContentIntent(pi).setAutoCancel(true).build()
        getSystemService(NotificationManager::class.java).notify(pkg.hashCode(), n)
    }

    override fun onRevoke() {
        getSharedPreferences("abo", MODE_PRIVATE).edit().putBoolean("on", false).apply()
        super.onRevoke()
    }

    override fun onDestroy() {
        if (registered) try { getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(cb) } catch (_: Exception) {}
        poller?.interrupt(); poller = null
        if (screenReg) try { unregisterReceiver(screenRx) } catch (_: Exception) {}
        screenReg = false
        tun?.close(); tun = null
        Hub.running = false
        super.onDestroy()
    }
}
