package com.abogeorge.block

import android.app.*
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.ParcelFileDescriptor
import org.json.JSONObject
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress

/**
 * Two modes:
 *  - classic: only apps that must be blocked are routed into the tunnel and dropped; allowed apps bypass the VPN.
 *  - relay (ad blocking and/or speed saver on): every app goes through [Relay]; blocked apps are dropped,
 *    DNS of ad domains is answered with NXDOMAIN, traffic can be rate limited.
 * The tunnel stays up with no Wi-Fi / mobile data, and the ad list is bundled, so nothing needs the network.
 */
class BlockVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    private var relay: Relay? = null
    private var mode = 0
    private var dnsKey = ""
    private var wifi = true
    private var registered = false
    @Volatile private var rules = JSONObject()
    @Volatile private var fw = true
    private val cb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(n: Network) = changed()
        override fun onLost(n: Network) = changed()
        override fun onCapabilitiesChanged(n: Network, c: NetworkCapabilities) = changed()
    }

    private fun isWifi(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java)
        @Suppress("DEPRECATION")
        return cm.allNetworks.any {
            val c = cm.getNetworkCapabilities(it)
            c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN) &&
                (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))
        }
    }

    /** IPv4 DNS servers of the real (non-VPN) network currently in use. */
    private fun dnsList(): List<String> {
        val cm = getSystemService(ConnectivityManager::class.java)
        val w = isWifi()
        val out = ArrayList<String>()
        @Suppress("DEPRECATION")
        for (n in cm.allNetworks) {
            val c = cm.getNetworkCapabilities(n) ?: continue
            if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)) continue
            val isW = c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
            if (isW != w) continue
            val lp = cm.getLinkProperties(n) ?: continue
            for (a in lp.dnsServers) if (a is Inet4Address) a.hostAddress?.let { if (!out.contains(it)) out.add(it) }
        }
        if (out.isEmpty()) { out.add("1.1.1.1"); out.add("8.8.8.8") }
        return out.take(3)
    }

    private fun changed() {
        if (isWifi() != wifi || (mode == 1 && dnsList().joinToString(",") != dnsKey)) apply()
    }

    private fun foreground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("blk", "ABO GEORGE BLOCK", NotificationManager.IMPORTANCE_MIN))
        nm.createNotificationChannel(NotificationChannel("pend", "طلبات الاتصال", NotificationManager.IMPORTANCE_DEFAULT))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "blk").setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("ABO GEORGE BLOCK").setContentText("الدرع يعمل")
            .setContentIntent(pi).setOngoing(true).build()
        startForeground(1, n)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        foreground()
        Blocklist.load(this)
        if (Hub.ads == 0L) Hub.ads = getSharedPreferences("abo", MODE_PRIVATE).getLong("adsTotal", 0L)
        if (!registered) {
            val cm = getSystemService(ConnectivityManager::class.java)
            cm.registerNetworkCallback(
                NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN).build(), cb)
            registered = true
        }
        apply()
        return START_STICKY
    }

    @Synchronized private fun apply() {
        val p = getSharedPreferences("abo", MODE_PRIVATE)
        if (!p.getBoolean("on", false)) { stopSelf(); return }
        wifi = isWifi()
        rules = try { JSONObject(p.getString("rules", "{}")!!) } catch (_: Exception) { JSONObject() }
        fw = p.getBoolean("fw", true)
        val ads = p.getBoolean("ads", false)
        val lim = p.getInt("limit_kb", 0)
        val limNow = lim > 0 && (!p.getBoolean("limmob", true) || !wifi)
        Throttle.bps = if (limNow) lim * 1024L else 0L
        if (ads || limNow) {
            val dns = dnsList()
            val key = dns.joinToString(",")
            relay?.adBlock = ads
            if (mode == 1 && tun != null && relay != null && key == dnsKey) {
                relay?.recheck()
                Hub.running = true
                return
            }
            startRelay(dns, key, ads)
        } else startClassic()
    }

    private fun startRelay(dns: List<String>, key: String, ads: Boolean) {
        val b = Builder().setSession("ABO GEORGE BLOCK").setMtu(1500).setMetered(!wifi)
            .addAddress("10.8.0.1", 32).addAddress("fd00::1", 128)
            .addRoute("0.0.0.0", 0).addRoute("::", 0)
        for (d in dns) try { b.addDnsServer(d) } catch (_: Exception) {}
        try { b.addDisallowedApplication(packageName) } catch (_: Exception) {}
        val oldRelay = relay
        val old = tun
        relay = null
        val fd = b.establish()
        oldRelay?.shutdown()
        old?.close()
        tun = fd
        if (fd == null) { mode = -1; Hub.running = false; return }
        val r = Relay(this, FileOutputStream(fd.fileDescriptor), this::decide, this::blockedUid) { name -> onAd(name) }
        r.adBlock = ads
        relay = r
        mode = 1
        dnsKey = key
        val ins = FileInputStream(fd.fileDescriptor)
        Thread {
            val buf = ByteArray(32767)
            while (true) {
                val n = try { ins.read(buf) } catch (_: Exception) { -1 }
                if (n < 0) break
                try { r.handle(buf, n) } catch (_: Throwable) {}
            }
        }.start()
        Hub.running = true
    }

    private fun startClassic() {
        relay?.shutdown(); relay = null
        mode = 0; dnsKey = ""
        val key = if (wifi) "w" else "m"
        val b = Builder().setSession("ABO GEORGE BLOCK")
            .addAddress("10.8.0.1", 32).addAddress("fd00::1", 128)
            .addRoute("0.0.0.0", 0).addRoute("::", 0)
        var n = 0
        for (a in packageManager.getInstalledApplications(0)) {
            if (a.packageName == packageName) continue
            if (!fw || rules.optJSONObject(a.packageName)?.optBoolean(key, false) == true) continue
            try { b.addAllowedApplication(a.packageName); n++ } catch (_: Exception) {}
        }
        if (n == 0) b.addAllowedApplication(packageName) // nothing to block: route nobody
        val old = tun
        tun = b.establish()
        old?.close()
        tun?.let { fd -> Thread { watch(fd) }.start() }
        Hub.running = tun != null
    }

    private fun onAd(name: String) {
        Hub.ad(name)
        if (Hub.ads % 20L == 0L) saveAds()
    }

    private fun saveAds() { getSharedPreferences("abo", MODE_PRIVATE).edit().putLong("adsTotal", Hub.ads).apply() }

    private fun blockedPk(pk: Array<String>): Boolean {
        if (!fw) return false
        val key = if (wifi) "w" else "m"
        return pk.none { rules.optJSONObject(it)?.optBoolean(key, false) == true }
    }

    private fun blockedUid(uid: Int): Boolean {
        val pk = packageManager.getPackagesForUid(uid) ?: return false
        return blockedPk(pk)
    }

    private val lastSeen = HashMap<Int, Long>()

    /** Relay mode: decides on the first packet of every flow. Returns the uid, or Relay.BLOCK. */
    private fun decide(proto: Int, src: ByteArray, sp: Int, dst: ByteArray, dp: Int): Int {
        try {
            val cm = getSystemService(ConnectivityManager::class.java)
            val da = InetAddress.getByAddress(dst)
            val uid = cm.getConnectionOwnerUid(proto, InetSocketAddress(InetAddress.getByAddress(src), sp), InetSocketAddress(da, dp))
            if (uid < 0) return 0
            val pk = packageManager.getPackagesForUid(uid)
            if (pk == null || pk.isEmpty() || !blockedPk(pk)) return uid
            val now = System.currentTimeMillis()
            val fresh = synchronized(lastSeen) {
                val f = now - (lastSeen[uid] ?: 0L) >= 4000
                if (f) lastSeen[uid] = now
                f
            }
            if (fresh) {
                Hub.add(pk[0], da.hostAddress ?: "", dp, if (wifi) "wifi" else "mobile")
                notifyPending(pk[0])
            }
            return Relay.BLOCK
        } catch (_: Exception) {
            return 0
        }
    }

    private val notified = HashSet<String>()

    /** Classic mode: reads packets from the tunnel (dropped, never forwarded) and reports who tried to connect. */
    private fun watch(fd: ParcelFileDescriptor) {
        val s = FileInputStream(fd.fileDescriptor)
        val buf = ByteArray(32767)
        val cm = getSystemService(ConnectivityManager::class.java)
        val last = HashMap<Int, Long>()
        while (true) {
            val n = try { s.read(buf) } catch (_: Exception) { -1 }
            if (n < 0) break
            try {
                val v = (buf[0].toInt() shr 4) and 15
                var hdr = 0; var proto = -1
                var src = ByteArray(0); var dst = ByteArray(0)
                if (v == 4 && n >= 24) {
                    hdr = (buf[0].toInt() and 15) * 4; proto = buf[9].toInt() and 255
                    src = buf.copyOfRange(12, 16); dst = buf.copyOfRange(16, 20)
                } else if (v == 6 && n >= 44) {
                    hdr = 40; proto = buf[6].toInt() and 255
                    src = buf.copyOfRange(8, 24); dst = buf.copyOfRange(24, 40)
                } else continue
                if ((proto != 6 && proto != 17) || n < hdr + 4) continue
                val sp = ((buf[hdr].toInt() and 255) shl 8) or (buf[hdr + 1].toInt() and 255)
                val dp = ((buf[hdr + 2].toInt() and 255) shl 8) or (buf[hdr + 3].toInt() and 255)
                val da = InetAddress.getByAddress(dst)
                val uid = cm.getConnectionOwnerUid(proto, InetSocketAddress(InetAddress.getByAddress(src), sp), InetSocketAddress(da, dp))
                if (uid < 0) continue
                val now = System.currentTimeMillis()
                if (now - (last[uid] ?: 0L) < 4000) continue
                last[uid] = now
                val pkg = packageManager.getPackagesForUid(uid)?.firstOrNull() ?: continue
                Hub.add(pkg, da.hostAddress ?: "", dp, if (wifi) "wifi" else "mobile")
                notifyPending(pkg)
            } catch (_: Exception) {}
        }
    }

    private fun notifyPending(pkg: String) {
        val p = getSharedPreferences("abo", MODE_PRIVATE)
        if (JSONObject(p.getString("rules", "{}")!!).has(pkg) || !notified.add(pkg)) return
        val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg }
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "pend").setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(label).setContentText("يحاول الاتصال بالإنترنت: اسمح له أو ارفضه")
            .setContentIntent(pi).setAutoCancel(true).build()
        getSystemService(NotificationManager::class.java).notify(pkg.hashCode(), n)
    }

    override fun onRevoke() {
        getSharedPreferences("abo", MODE_PRIVATE).edit().putBoolean("on", false).apply()
        super.onRevoke()
    }

    override fun onDestroy() {
        if (registered) try { getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(cb) } catch (_: Exception) {}
        relay?.shutdown(); relay = null
        Throttle.bps = 0L
        saveAds()
        tun?.close(); tun = null
        mode = 0
        Hub.running = false
        super.onDestroy()
    }
}
