package com.abogeorge.block

import android.net.ConnectivityManager
import android.net.NetworkCapabilities

/** Shared network detection, used by both the UI and the VPN service. */
object Net {
    /**
     * true = Wi-Fi/Ethernet is the network actually carrying traffic.
     * A Wi-Fi that is connected but has no working internet does NOT count when mobile data works.
     */
    @Suppress("DEPRECATION")
    fun isWifi(cm: ConnectivityManager): Boolean {
        var anyWifi = false
        var validWifi = false
        var validMobile = false
        for (n in cm.allNetworks) {
            val c = cm.getNetworkCapabilities(n) ?: continue
            if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)) continue
            val valid = c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            val w = c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
            if (w) {
                anyWifi = true
                if (valid) validWifi = true
            } else if (valid) {
                validMobile = true
            }
        }
        return when {
            validWifi -> true
            validMobile -> false
            else -> anyWifi
        }
    }
}
