package com.abogeorge.block

import android.content.Context

/** IPv4 packet building helpers (checksums, TCP/UDP headers). */
object Pkt {
    fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 255) shl 8) or (b[o + 1].toInt() and 255)
    fun u32(b: ByteArray, o: Int): Long =
        ((b[o].toLong() and 255) shl 24) or ((b[o + 1].toLong() and 255) shl 16) or
            ((b[o + 2].toLong() and 255) shl 8) or (b[o + 3].toLong() and 255)

    fun p16(b: ByteArray, o: Int, v: Int) { b[o] = (v shr 8).toByte(); b[o + 1] = v.toByte() }
    fun p32(b: ByteArray, o: Int, v: Long) {
        b[o] = (v shr 24).toByte(); b[o + 1] = (v shr 16).toByte(); b[o + 2] = (v shr 8).toByte(); b[o + 3] = v.toByte()
    }

    private fun sum(b: ByteArray, off: Int, len: Int, init: Long): Long {
        var s = init
        var i = off
        val end = off + len
        while (i + 1 < end) { s += u16(b, i); i += 2 }
        if (i < end) s += (b[i].toInt() and 255) shl 8
        return s
    }

    private fun fold(s0: Long): Int {
        var s = s0
        while ((s shr 16) != 0L) s = (s and 0xffff) + (s shr 16)
        return (s.inv() and 0xffff).toInt()
    }

    private fun ip(b: ByteArray, total: Int, proto: Int, src: ByteArray, dst: ByteArray) {
        b[0] = 0x45
        p16(b, 2, total)
        b[6] = 0x40
        b[8] = 64
        b[9] = proto.toByte()
        System.arraycopy(src, 0, b, 12, 4)
        System.arraycopy(dst, 0, b, 16, 4)
        p16(b, 10, fold(sum(b, 0, 20, 0L)))
    }

    fun tcp(src: ByteArray, dst: ByteArray, sp: Int, dp: Int, seq: Long, ack: Long, fl: Int, win: Int,
            d: ByteArray?, n: Int, mss: Boolean): ByteArray {
        val th = if (mss) 24 else 20
        val tl = th + n
        val b = ByteArray(20 + tl)
        ip(b, 20 + tl, 6, src, dst)
        p16(b, 20, sp); p16(b, 22, dp); p32(b, 24, seq); p32(b, 28, ack)
        b[32] = ((th / 4) shl 4).toByte()
        b[33] = fl.toByte()
        p16(b, 34, win)
        if (mss) { b[40] = 2; b[41] = 4; p16(b, 42, 1360) }
        if (d != null && n > 0) System.arraycopy(d, 0, b, 20 + th, n)
        val s = sum(b, 12, 8, 6L + tl)
        p16(b, 36, fold(sum(b, 20, tl, s)))
        return b
    }

    /** UDP over IPv4 with a zero checksum (allowed by the standard). */
    fun udp(src: ByteArray, dst: ByteArray, sp: Int, dp: Int, d: ByteArray, n: Int): ByteArray {
        val b = ByteArray(28 + n)
        ip(b, 28 + n, 17, src, dst)
        p16(b, 20, sp); p16(b, 22, dp); p16(b, 24, 8 + n)
        System.arraycopy(d, 0, b, 28, n)
        return b
    }
}

class Q(val name: String, val type: Int, val end: Int)

object Dns {
    /** Parses the first question of a DNS query. Returns null for responses / malformed packets. */
    fun parse(b: ByteArray, off: Int, len: Int): Q? {
        if (len < 17 || (b[off + 2].toInt() and 0x80) != 0 || Pkt.u16(b, off + 4) < 1) return null
        val sb = StringBuilder()
        var p = off + 12
        val end = off + len
        while (p < end) {
            val l = b[p].toInt() and 255
            if (l == 0) break
            if ((l and 0xC0) != 0 || p + 1 + l > end) return null
            if (sb.isNotEmpty()) sb.append('.')
            for (i in 1..l) sb.append((b[p + i].toInt() and 255).toChar())
            p += l + 1
        }
        if (p + 5 > end) return null
        return Q(sb.toString(), Pkt.u16(b, p + 1), p + 5)
    }

    /** Builds an empty answer: rcode 3 = NXDOMAIN (blocked), rcode 0 = NODATA. */
    fun reply(b: ByteArray, off: Int, q: Q, rcode: Int): ByteArray {
        val r = b.copyOfRange(off, q.end)
        r[2] = (0x80 or (r[2].toInt() and 0x01)).toByte()
        r[3] = (0x80 or rcode).toByte()
        for (i in 6..11) r[i] = 0
        return r
    }
}

/** Global download/upload limiter shared by every relayed flow (token bucket with a 250 ms burst). */
object Throttle {
    @Volatile var bps = 0L
    private var next = 0L

    fun take(n: Int) {
        val r = bps
        if (r <= 0) return
        var wait = 0L
        synchronized(this) {
            val now = System.nanoTime()
            if (next < now - 250_000_000L) next = now - 250_000_000L
            next += n * 1_000_000_000L / r
            wait = next - now
        }
        if (wait > 0) try { Thread.sleep(wait / 1_000_000L, (wait % 1_000_000L).toInt()) } catch (_: InterruptedException) {}
    }
}

/** Bundled ad / tracker domain list (assets/blocklist.txt). Works fully offline; subdomains match too. */
object Blocklist {
    @Volatile private var set: HashSet<String> = HashSet()

    fun load(ctx: Context) {
        val s = HashSet<String>()
        try {
            ctx.assets.open("blocklist.txt").bufferedReader().useLines { ls ->
                ls.forEach { l ->
                    val d = l.substringBefore('#').trim().lowercase()
                    if (d.isNotEmpty()) s.add(d)
                }
            }
        } catch (_: Exception) {}
        set = s
    }

    fun matches(name: String): Boolean {
        var h = name.lowercase().trimEnd('.')
        while (true) {
            if (set.contains(h)) return true
            val i = h.indexOf('.')
            if (i < 0) return false
            h = h.substring(i + 1)
        }
    }
}
