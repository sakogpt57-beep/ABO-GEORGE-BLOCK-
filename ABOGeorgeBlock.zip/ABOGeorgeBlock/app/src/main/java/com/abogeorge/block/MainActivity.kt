package com.abogeorge.block

import android.app.Activity
import android.app.AppOpsManager
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.graphics.Color
import android.util.Base64
import android.view.View
import java.io.ByteArrayOutputStream
import android.net.VpnService
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private fun prefs() = getSharedPreferences("abo", MODE_PRIVATE)
    private fun svc() = Intent(this, BlockVpnService::class.java)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 2)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("simple flow")
    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        if (r != 1) return
        if (c == RESULT_OK) startForegroundService(svc()) else {
            prefs().edit().putBoolean("on", false).apply()
            web.evaluateJavascript("S.on=false;save();render()", null)
        }
    }

    inner class Bridge {
        @JavascriptInterface fun getApps(): String = try { appsJson() } catch (e: Throwable) { "[]" }
        private fun appsJson(): String {
            val pm = packageManager
            val list = pm.getInstalledApplications(0).filter {
                it.packageName != packageName &&
                    pm.checkPermission("android.permission.INTERNET", it.packageName) == PackageManager.PERMISSION_GRANTED
            }.sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
            val a = JSONArray()
            for (i in list) a.put(JSONObject().put("n", pm.getApplicationLabel(i).toString())
                .put("p", i.packageName).put("s", (i.flags and ApplicationInfo.FLAG_SYSTEM) != 0))
            return a.toString()
        }
        @JavascriptInterface fun getEvents(since: String): String = Hub.since(since.toLongOrNull() ?: 0L)
        @JavascriptInterface fun isRunning(): Boolean = Hub.running
        @JavascriptInterface fun getRules(): String = prefs().getString("rules", "{}")!!
        @JavascriptInterface fun setRules(j: String) { prefs().edit().putString("rules", j).apply() }
        @JavascriptInterface fun isOn(): Boolean = prefs().getBoolean("on", false)
        @JavascriptInterface fun setVpn(on: Boolean) {
            prefs().edit().putBoolean("on", on).apply()
            runOnUiThread {
                if (on) {
                    val i = VpnService.prepare(this@MainActivity)
                    if (i != null) startActivityForResult(i, 1) else startForegroundService(svc())
                } else stopService(svc())
            }
        }
        @JavascriptInterface fun getFw(): Boolean = prefs().getBoolean("fw", true)
        @JavascriptInterface fun setFw(b: Boolean) { prefs().edit().putBoolean("fw", b).apply() }
        @JavascriptInterface fun getAds(): Boolean = prefs().getBoolean("ads", false)
        @JavascriptInterface fun setAds(b: Boolean) { prefs().edit().putBoolean("ads", b).apply() }
        @JavascriptInterface fun getLimit(): Int = prefs().getInt("limit_kb", 0)
        @JavascriptInterface fun setLimit(kb: Int) { prefs().edit().putInt("limit_kb", kb).apply() }
        @JavascriptInterface fun getLimitMob(): Boolean = prefs().getBoolean("limmob", true)
        @JavascriptInterface fun setLimitMob(b: Boolean) { prefs().edit().putBoolean("limmob", b).apply() }
        @JavascriptInterface fun getAdStats(): String {
            if (Hub.ads == 0L) Hub.ads = prefs().getLong("adsTotal", 0L)
            return Hub.adJson()
        }
        @JavascriptInterface fun resetAds() { Hub.resetAds(); prefs().edit().putLong("adsTotal", 0L).apply() }
        @JavascriptInterface fun setBars(dark: Boolean) {
            runOnUiThread {
                val c = if (dark) Color.parseColor("#0A0F1E") else Color.parseColor("#F1F5FC")
                window.statusBarColor = c
                window.navigationBarColor = c
                @Suppress("DEPRECATION")
                val v = window.decorView
                @Suppress("DEPRECATION")
                val light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
                @Suppress("DEPRECATION")
                v.systemUiVisibility = if (dark) v.systemUiVisibility and light.inv() else v.systemUiVisibility or light
            }
        }
        @JavascriptInterface fun getBoot(): Boolean = prefs().getBoolean("boot", true)
        @JavascriptInterface fun setBoot(b: Boolean) { prefs().edit().putBoolean("boot", b).apply() }
        @JavascriptInterface fun getNet(): String {
            val cm = getSystemService(ConnectivityManager::class.java)
            var w = false
            var any = false
            @Suppress("DEPRECATION")
            for (n in cm.allNetworks) {
                val c = cm.getNetworkCapabilities(n) ?: continue
                if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)) continue
                any = true
                if (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) w = true
            }
            return if (w) "wifi" else if (any) "mobile" else "none"
        }
        @JavascriptInterface fun getIcon(p: String): String = try {
            val bm = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
            val d = packageManager.getApplicationIcon(p)
            d.setBounds(0, 0, 96, 96); d.draw(Canvas(bm))
            val o = ByteArrayOutputStream(); bm.compress(Bitmap.CompressFormat.PNG, 100, o)
            Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
        } catch (_: Exception) { "" }
        @JavascriptInterface fun hasUsageAccess(): Boolean {
            val ao = getSystemService(AppOpsManager::class.java)
            @Suppress("DEPRECATION")
            return ao.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
        }
        @JavascriptInterface fun openUsageSettings() {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        @JavascriptInterface fun getUsage(since: String): String {
            val nsm = getSystemService(NetworkStatsManager::class.java)
            val from = since.toLongOrNull() ?: 0L
            val now = System.currentTimeMillis()
            val byUid = HashMap<Int, LongArray>()
            for ((type, idx) in listOf(ConnectivityManager.TYPE_WIFI to 0, ConnectivityManager.TYPE_MOBILE to 1)) {
                try {
                    val st = nsm.querySummary(type, null, from, now)
                    val b = NetworkStats.Bucket()
                    while (st.hasNextBucket()) {
                        st.getNextBucket(b)
                        byUid.getOrPut(b.uid) { LongArray(2) }[idx] += b.rxBytes + b.txBytes
                    }
                    st.close()
                } catch (_: Exception) {}
            }
            val out = JSONObject()
            for (i in packageManager.getInstalledApplications(0))
                byUid[i.uid]?.let { out.put(i.packageName, JSONObject().put("w", it[0]).put("m", it[1])) }
            return out.toString()
        }
    }
}
