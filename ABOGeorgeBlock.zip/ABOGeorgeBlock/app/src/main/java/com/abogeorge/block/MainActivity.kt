package com.abogeorge.block

import android.app.Activity
import android.app.AppOpsManager
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.ConnectivityManager
import android.net.TrafficStats
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var asking = false
    private fun prefs() = getSharedPreferences("abo", MODE_PRIVATE)
    private fun svc() = Intent(this, BlockVpnService::class.java)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        // ask for the notification permission once, not at every launch
        if (Build.VERSION.SDK_INT >= 33 && !prefs().getBoolean("askedNotif", false)) {
            prefs().edit().putBoolean("askedNotif", true).apply()
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 2)
        }
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
    }

    /** make the page re-read the real state (VPN on/off, network, installed apps) */
    private fun refreshUi() {
        if (::web.isInitialized) web.evaluateJavascript("window.refreshState&&refreshState()", null)
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
    }

    @Deprecated("simple flow")
    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        if (r != 1) return
        asking = false
        if (c == RESULT_OK) startForegroundService(svc()) else {
            prefs().edit().putBoolean("on", false).apply()
            Hub.err = "لم يتم منح إذن VPN"
        }
        refreshUi()
    }

    inner class Bridge {
        @JavascriptInterface fun getApps(): String = try { appsJson() } catch (e: Throwable) { "[]" }
        private fun appsJson(): String {
            val pm = packageManager
            val list = pm.getInstalledApplications(0).filter {
                it.packageName != packageName &&
                    pm.checkPermission("android.permission.INTERNET", it.packageName) == PackageManager.PERMISSION_GRANTED
            }.sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
            val a = JSONArray()
            for (i in list) a.put(JSONObject().put("n", pm.getApplicationLabel(i).toString())
                .put("p", i.packageName).put("s", (i.flags and ApplicationInfo.FLAG_SYSTEM) != 0))
            return a.toString()
        }
        @JavascriptInterface fun getBg(): Boolean = prefs().getBoolean("bg", false)
        @JavascriptInterface fun getSoff(): Boolean = prefs().getBoolean("soff", false)
        @JavascriptInterface fun setSaver(bg: Boolean, soff: Boolean) { prefs().edit().putBoolean("bg", bg).putBoolean("soff", soff).apply() }
        @JavascriptInterface fun getCapped(): Boolean = prefs().getBoolean("capped", false)
        @JavascriptInterface fun setCapped(c: Boolean) { prefs().edit().putBoolean("capped", c).apply() }
        @JavascriptInterface fun getErr(): String = Hub.err
        @JavascriptInterface fun getTraffic(): String =
            "${TrafficStats.getTotalRxBytes()},${TrafficStats.getTotalTxBytes()},${TrafficStats.getMobileRxBytes()},${TrafficStats.getMobileTxBytes()}"
        @JavascriptInterface fun copy(t: String) {
            getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("dns", t))
        }
        @JavascriptInterface fun openNetSettings() {
            startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        @JavascriptInterface fun getEvents(since: String): String = Hub.since(since.toLongOrNull() ?: 0L)
        @JavascriptInterface fun isRunning(): Boolean = Hub.running
        @JavascriptInterface fun getRules(): String = prefs().getString("rules", "{}") ?: "{}"
        @JavascriptInterface fun setRules(j: String) { prefs().edit().putString("rules", j).apply() }
        @JavascriptInterface fun isOn(): Boolean = prefs().getBoolean("on", false)
        @JavascriptInterface fun setVpn(on: Boolean) {
            prefs().edit().putBoolean("on", on).apply()
            runOnUiThread {
                try {
                    if (on) {
                        val i = VpnService.prepare(this@MainActivity)
                        if (i != null) {
                            if (!asking) { asking = true; startActivityForResult(i, 1) }
                        } else startForegroundService(svc())
                    } else stopService(svc())
                } catch (e: Throwable) {
                    Hub.err = "تعذّر تشغيل الجدار: " + e.javaClass.simpleName + " " + (e.message ?: "")
                }
            }
        }
        @JavascriptInterface fun getBoot(): Boolean = prefs().getBoolean("boot", true)
        @JavascriptInterface fun setBoot(b: Boolean) { prefs().edit().putBoolean("boot", b).apply() }
        @JavascriptInterface fun getNet(): String =
            if (Net.isWifi(getSystemService(ConnectivityManager::class.java))) "wifi" else "mobile"
        @JavascriptInterface fun getIcon(p: String): String = try {
            val bm = Bitmap.createBitmap(72, 72, Bitmap.Config.ARGB_8888)
            val d = packageManager.getApplicationIcon(p)
            d.setBounds(0, 0, 72, 72); d.draw(Canvas(bm))
            val o = ByteArrayOutputStream(); bm.compress(Bitmap.CompressFormat.PNG, 100, o)
            Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
        } catch (_: Exception) { "" }
        @JavascriptInterface fun hasUsageAccess(): Boolean {
            val ao = getSystemService(AppOpsManager::class.java)
            @Suppress("DEPRECATION")
            return ao.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
        }
        @JavascriptInterface fun openUsageSettings() {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }

        private var uCache = ""
        private var uAt = 0L
        private var uSince = -1L

        /** bytes per package (w = wifi, m = mobile, u = uid so the page can avoid double counting shared uids) */
        @JavascriptInterface fun getUsage(since: String): String {
            val from = since.toLongOrNull() ?: 0L
            val now = System.currentTimeMillis()
            synchronized(this) {
                if (from == uSince && uCache.isNotEmpty() && now - uAt < 4000) return uCache
            }
            val nsm = getSystemService(NetworkStatsManager::class.java)
            val byUid = HashMap<Int, LongArray>()
            for ((type, idx) in listOf(ConnectivityManager.TYPE_WIFI to 0, ConnectivityManager.TYPE_MOBILE to 1)) {
                try {
                    val st = nsm.querySummary(type, null, from, now)
                    val b = NetworkStats.Bucket()
                    while (st.hasNextBucket()) {
                        st.getNextBucket(b)
                        byUid.getOrPut(b.uid) { LongArray(2) }[idx] += b.rxBytes + b.txBytes
                    }
                    st.close()
                } catch (_: Exception) {}
            }
            val out = JSONObject()
            for (i in packageManager.getInstalledApplications(0))
                byUid[i.uid]?.let { out.put(i.packageName, JSONObject().put("w", it[0]).put("m", it[1]).put("u", i.uid)) }
            val res = out.toString()
            synchronized(this) { uCache = res; uAt = now; uSince = from }
            return res
        }
    }
}
