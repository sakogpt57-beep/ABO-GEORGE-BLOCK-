package com.abogeorge.block

import org.json.JSONArray
import org.json.JSONObject

/** In-memory bridge between the VPN service (writer) and the UI (reader). */
object Hub {
    @Volatile var running = false
    @Volatile var err = ""
    private var nextId = 0L
    private val events = ArrayDeque<JSONObject>()

    @Synchronized fun add(pkg: String, dst: String, port: Int, net: String) {
        nextId++
        events.addLast(JSONObject().put("id", nextId).put("t", System.currentTimeMillis())
            .put("p", pkg).put("d", dst).put("pt", port).put("n", net))
        while (events.size > 300) events.removeFirst()
    }

    @Synchronized fun since(id: Long): String {
        // if the process restarted the counter went back to 0: send everything again
        val from = if (id > nextId) 0L else id
        val a = JSONArray()
        for (e in events) if (e.getLong("id") > from) a.put(e)
        return JSONObject().put("ev", a).put("max", nextId).toString()
    }
}
